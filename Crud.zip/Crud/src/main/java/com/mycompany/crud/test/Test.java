package com.mycompany.crud.test;

import com.mycompany.crud.bo.EmpleadoBO;
import com.mycompany.crud.entity.Empleado;
import java.sql.SQLException;

public class Test {

    EmpleadoBO ebo = new EmpleadoBO();
    Empleado emp = new Empleado();
    String mensaje = "";

    public void insertar() throws SQLException {
       emp.setNombre_Completo("Bryan");
        emp.setapellidos("Amaya");
        emp.setCedula("90202020");
        emp.setEstado_Civil('S');
        emp.setGenero('M');
        emp.setEdad(23);
       
        /*emp.setNombre_Completo("Sarahi");
        emp.setapellidos("Hernandez Rios");
        emp.setCedula("1452368900");
        emp.setEstado_Civil('C');
        emp.setGenero('F');
        emp.setEdad(21);*/
       
        mensaje = ebo.agregarEmpleado(emp);
        System.out.println(mensaje);
    }
    
    
     public void modificar() throws SQLException {
       /* emp.setNombre_Completo("Bryan");
        emp.setapellidos("Amaya");
        emp.setCedula("90202020");
        emp.setEstado_Civil('S');
        emp.setGenero('M');
        emp.setEdad(23);*/
       
      /* emp.setId_Empleado(1);
        emp.setNombre_Completo("Brayan");
        emp.setapellidos("Amaya Delgado");
        emp.setCedula("1452368900");
        emp.setEstado_Civil('C');
        emp.setGenero('M');
        emp.setEdad(21);*/
       
        mensaje = ebo.modificarEmpleado(emp);
        System.out.println(mensaje);
    }
     
     
    
     public void eliminar() throws SQLException {
      
        mensaje = ebo.eliminarEmpleado(2);
        System.out.println(mensaje);
    }
    
    public static void main(String[] args) throws SQLException {
        Test test = new Test();
       // test.insertar();
    }
    
}
