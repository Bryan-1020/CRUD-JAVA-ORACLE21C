package com.mycompany.crud.entity;

public class Empleado {
    
    private int id_Empleado;
    private String nombre_Completo;
    private String apellidos;
    private String cedula;
    private char estado_Civil;
    private char genero;
    private int edad; 

    public Empleado() {
    }

    public Empleado(int id_Empleado, String nombre_Completo, String apellidos, String cedula, char estado_Civil, char genero, int edad) {
        this.id_Empleado = id_Empleado;
        this.nombre_Completo = nombre_Completo;
        this.apellidos = apellidos;
        this.cedula = cedula;
        this.estado_Civil = estado_Civil;
        this.genero = genero;
        this.edad = edad;
    }

    public int getId_Empleado() {
        return id_Empleado;
    }

    public void setId_Empleado(int id_Empleado) {
        this.id_Empleado = id_Empleado;
    }

    public String getNombre_Completo() {
        return nombre_Completo;
    }

    public void setNombre_Completo(String nombre_Completo) {
        this.nombre_Completo = nombre_Completo;
    }
    //+++++++++++++++++++++++++++++++++++
     public String getapellidos() {
        return apellidos;
    }

    public void setapellidos(String apellidos) {
        this.apellidos = apellidos;
    }
//++++++++++++++++++++++++++++++++++++++++++++
    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public char getEstado_Civil() {
        return estado_Civil;
    }

    public void setEstado_Civil(char estado_Civil) {
        this.estado_Civil = estado_Civil;
    }

    public char getGenero() {
        return genero;
    }

    public void setGenero(char genero) {
        this.genero = genero;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return "EMPLEADO{" + "id_Empleado=" + id_Empleado + ", nombre_Completo=" + nombre_Completo+  ", apellidos=" + apellidos + ", cedula=" + cedula + ", estado_Civil=" + estado_Civil + ", genero=" + genero + ", edad=" + edad + '}';
    }
    
    
    
}
