package com.mycompany.crud.db;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Conexion {
    
    private static Connection conn = null;

    private static String user = "desarrollo";
    private static String clave = "Passw0rd";
   // private static String url = "jdbc:oracle:thin:@localhost:1521:produccion";
    private static String url = "jdbc:oracle:thin:@192.168.15.22:1522:produccion1";

    public static Connection getConnection() {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            conn = DriverManager.getConnection(url, user, clave);
            conn.setAutoCommit(false);
            
              if (conn != null) {
                System.out.println("Acceso Exitoso");
            } else {
                System.out.println("Acceso Fallido");
            }
              
        } catch (ClassNotFoundException | SQLException e) {
          
            JOptionPane.showMessageDialog(null, "Error de Conexion" + e.getMessage());
        }
        return conn;
    }
    
    public void desconexion (){
            try {
                conn.close();
            } catch (SQLException e) {
            System.out.println("Error al Desconectar: " + e.getMessage());
            }
    }

    public static void main(String[] args){ 
        Conexion c = new Conexion();
        Conexion.getConnection(); 
    }

    
}

